
document.addEventListener("DOMContentLoaded", function () {

    const carousel = document.querySelector(".hero-carousel");

    setTimeout(function () {
        carousel.classList.add("show");
    }, 200);

});


document.addEventListener("DOMContentLoaded", function () {

    // Select all sections with zoom-section class
    const sections = document.querySelectorAll(".zoom-section");

    // Observe each section separately
    const observer = new IntersectionObserver(function (entries) {

        entries.forEach(function (entry) {

            // Start animation when section enters viewport
            if (entry.isIntersecting) {

                entry.target.classList.add("show");

                // Run only once for this section
                observer.unobserve(entry.target);
            }

        });

    }, {
        threshold: 0.1
    });

    // Observe every matching section
    sections.forEach(function (section) {
        observer.observe(section);
    });

});
